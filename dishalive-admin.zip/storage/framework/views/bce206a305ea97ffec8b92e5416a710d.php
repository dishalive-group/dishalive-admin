
<?php $__env->startSection('main-section'); ?>
<div class="login">
	<div class="wrapper wrapper-login wrapper-login-full p-0">
		<div class="login-aside w-50 d-flex flex-column align-items-center justify-content-center text-center bg-secondary-gradient">
		    <a href="/" title="DishaLive Web Design and Solutions">
			    <img src="<?php echo e($logo); ?>" alt="DishaLive Logo" class="img-fluid w-50">
			</a>
			<h1 class="title fw-bold text-white mb-3">Welcome to Admin Panel</h1>
			<h3 class="fw-bold text-white mb-3">To Rock, Keep updating</h3>
			<p class="text-white op-7">We're for you with someting awesome.</p>
							
			
			</p>
			
			<p class="text-white">Developed by <a href="https://www.dishalive.com" class="link link-primary text-white">DishaLive Web Design and Solutions</a></p>
			
		</div>
		<div class="login-aside w-50 d-flex align-items-center justify-content-center bg-white">
			<div class="container container-login container-transparent animated fadeIn">
				<h3 class="text-center">Sign In</h3>
				<div class="login-form">
				<form action="/login" method="POST">
                    <?php echo csrf_field(); ?>                  
                        <input type="number" name="mobileNo" class="form-control" value="<?php echo e(old('mobileNo')); ?>" placeholder="Enter your mobile number"><br>
                        <?php $__errorArgs = ['mobileNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                        <input type="password" name="password" class="form-control" placeholder="Enter Password">
                        <?php $__errorArgs = ['passowrd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <br>
                        
                        <div class="form-group<?php echo e($errors->has('g-recaptcha-response') ? ' has-error' : ''); ?>">
                            <div class="col-md-6">
                                
                                <?php if($errors->has('g-recaptcha-response')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <input type="submit" class="btn btn-primary w-100" name='submit' value="Login" >
                                            
                        <!-- <div class="py-5">
                            <a href='#' class="float-start btn btn-info"> <i class="fa fa-key"></i> Reset Password </a>
                            <a href="#" id="show-signup" class="float-end btn btn-info"> <i class="fa fa-user-plus"></i> Register Now</a>
                        </div>                         -->
                    </form> 
				</div>
			</div>

			<div class="container container-signup container-transparent animated fadeIn">
				<h3 class="text-center">Create new account</h3>
				<div class="login-form">
					<form action="/register" method="POST">
					<?php echo csrf_field(); ?>
						<div class="row">
							<div class="col-md-12 pb-2">
								<label>Country</label>
								<select name="country" id="country" class="form-control" required>
									<option value="">Select any one</option>
									<option value="77" data-prefix="+91">India</option>									
								</select>
							</div>
							<div class="col-4 pb-2">
								<label>Prefix</label>
								<input type="text" name="mobileNoPrefix" id="mobileNoPrefix" class="form-control" placeholder="Mobile No. Prefix" required="">
								<?php $__errorArgs = ['mobileNoPrefix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class="col-8 pb-2">
								<label>Mobile No.</label>
								<input type="number" name="mobileNo" class="form-control" placeholder="Enter Your Mobile Number" required="" value="<?php echo e(old('mobileNo')); ?>">
								<?php $__errorArgs = ['mobileNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class="col-md-12 pb-2">					
								<label>Your Name</label>
								<input type="text" name="name" class="form-control" placeholder="Enter Your Name" required="" value="<?php echo e(old('name')); ?>">
								<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class="col-md-12 pb-2">
								<label>Email</label>
								<input type="email" name="email" class="form-control" placeholder="Enter your email" required="" value="<?php echo e(old('email')); ?>">
								<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class="col-md-6 pb-2">
								<label>Password</label>
								<input type="password" name="password" class="form-control" placeholder="Enter new password " required="">
								<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                        
							</div>
							<div class="col-md-6 pb-2">
								<label>Retype Password</label>
								<input type="password" name="password_confirmation" class="form-control" placeholder="Retype password " required="">
								<?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                        
							</div>
							<div class="col-12 pt-3">
								<input type="submit" name="submit" value="Register Now!" class="btn btn-primary w-100">
							</div>
							<div class="text-center pt-3">
								<a href="reset-password"> <i class="fa fa-key"></i> Forgot Password? Reset Now!</a> &#160; 
								<a href="#" id="show-signin"><i class="fa fa-user"></i> Login Account</a>
							</div>					
						</div>				
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
	<script>
		// Add an event listener to the country dropdown
		document.getElementById('country').addEventListener('change', function () {
			// Get the selected option
			var selectedOption = this.options[this.selectedIndex];

			// Get the mobile prefix from the data attribute
			var mobilePrefix = selectedOption.getAttribute('data-prefix');

			// Populate the mobileNoPrefix input field
			document.getElementById('mobileNoPrefix').value = mobilePrefix;
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("dashboard.layouts.frontend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\localseo\resources\views/dashboard/login.blade.php ENDPATH**/ ?>