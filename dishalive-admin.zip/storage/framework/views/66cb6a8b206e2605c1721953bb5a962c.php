
<?php $__env->startPush("meta"); ?>
    <title>Dashboard</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection("main-section"); ?>

<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				<div class="d-flex align-items-center">
					<h4 class="card-title">Dashboard</h4>
					<a href="/dashboard/reports" class="btn btn-primary btn-round ml-auto">
						<i class="fa fa-list"></i>
						Reports
					</a>
				</div>
			</div>
			<div class="card-body">
				
				<div class="row">
					<div class="col-sm-6 col-md-4">
						<a href="/dashboard/user-campaigns">
						<div class="card card-stats card-primary card-round">
							<div class="card-body">
								<div class="row">
									<div class="col-3">
										<div class="icon-big text-center">
											<i class="fas fa-chart-pie"></i>
										</div>
									</div>
									<div class="col-9 col-stats">
										<div class="numbers">
											<h4 class="card-title">Campaigns</h4>
										</div>
									</div>
								</div>
							</div>
						</div>
						</a>
					</div>
					<div class="col-sm-6 col-md-4">
						<a href="/dashboard/reports">
						<div class="card card-stats card-primary card-round">
							<div class="card-body">
								<div class="row">
									<div class="col-3">
										<div class="icon-big text-center">
											<i class="fas fa-chart-pie"></i>
										</div>
									</div>
									<div class="col-9 col-stats">
										<div class="numbers">
											<h4 class="card-title">Reports</h4>
										</div>
									</div>
								</div>
							</div>
						</div>
						</a>
					</div>
					<div class="col-sm-6 col-md-4">
						<a href="/dashboard/transactions">
						<div class="card card-stats card-primary card-round">
							<div class="card-body">
								<div class="row">
									<div class="col-3">
										<div class="icon-big text-center">
											<i class="fas fa-piggy-bank"></i>
										</div>
									</div>
									<div class="col-9 col-stats">
										<div class="numbers">
											<h4 class="card-title">Credits:</h4>
										</div>
									</div>
								</div>
							</div>
						</div>
						</a>
					</div>

				</div>
			</div>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("dashboard.layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\localseo\resources\views/dashboard/index.blade.php ENDPATH**/ ?>