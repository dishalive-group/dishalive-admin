
<?php $__env->startPush("meta"); ?>
    <title>Dashboard | MyDL.in</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection("main-section"); ?>

<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				<div class="d-flex align-items-center">
					<h4 class="card-title">Change Password</h4>					
				</div>
			</div>
			<div class="card-body">
				<?php if(session('errorMsg')): ?>
					<div class="alert alert-danger">
						<?php echo e(session('errorMsg')); ?>

					</div>
				<?php endif; ?>

				<form method="POST" action="/change-password">
					<?php echo csrf_field(); ?>

					<div class="form-group row">
						<label for="old_password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Old Password')); ?></label>

						<div class="col-md-6">
							<input id="old_password" type="password" class="form-control <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="old_password" required autocomplete="old-password">

							<?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</div>

					<div class="form-group row mt-2">
						<label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('New Password')); ?></label>

						<div class="col-md-6">
							<input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

							<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</div>

					<div class="form-group row mt-2">
						<label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

						<div class="col-md-6">
							<input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
						</div>
					</div>

					<div class="form-group row mb-0 mt-2">
						<div class="col-md-6 offset-md-4">
							<button type="submit" class="btn btn-primary">
								<?php echo e(__('Change Password')); ?>

							</button>
						</div>
					</div>
				</form>
			</div>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("dashboard.layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\localseo\resources\views/dashboard/change-password.blade.php ENDPATH**/ ?>